package com.example.notesapp;

public class Note {
    private String id;
    private String note;
    private Boolean created = false;

    public Note(String note) {
        this.note = note;
    }

    public Note() {

    }
    public String getId() {
        return id;
    }

    public String getNote() {
        return note;
    }

    public Boolean getCreated() { return created; }

    public void setCreated(Boolean created) { this.created = created; }

    public void setId(String id) {
        this.id = id;
    }

    public void setNote(String note) {
        this.note = note;
    }
}
