package com.example.notesapp;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.widget.EditText;

import com.example.notesapp.data.DatabaseHelper;

import java.util.ArrayList;
import java.util.List;

public class NoteListActivity extends AppCompatActivity implements NoteAdapter.OnRowClickListener {

    RecyclerView noteRecyclerView;
    NoteAdapter noteAdapter;
    DatabaseHelper db;
    List<Note> notesList;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_note_list);
        noteRecyclerView = findViewById(R.id.noteRecyclerView);
        db = new DatabaseHelper(NoteListActivity.this);
        notesList = db.fetchAllNotes();
        noteAdapter = new NoteAdapter(notesList, NoteListActivity.this, this);
        RecyclerView.LayoutManager layoutManager = new LinearLayoutManager(this, LinearLayoutManager.VERTICAL, false);
        noteRecyclerView.setLayoutManager(layoutManager);
        noteRecyclerView.setAdapter(noteAdapter);
    }

    @Override
    public void onItemClick(int position) {
        Intent noteIntent = new Intent(NoteListActivity.this, NoteActivity.class);
        noteIntent.putExtra("Note", notesList.get(position).getNote());
        noteIntent.putExtra("Id", notesList.get(position).getId());
        noteIntent.putExtra("Created", true);
        startActivity(noteIntent);
        finish();
    }
}