package com.example.notesapp;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.example.notesapp.data.DatabaseHelper;

import java.io.Serializable;

public class NoteActivity extends AppCompatActivity implements Serializable{

    Button saveNoteButton;
    Button updateNoteButton;
    Button deleteNoteButton;
    EditText noteEditText;
    String noteMessage;
    DatabaseHelper db;
    Note currentNote;
    Boolean created;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_note);
        created = getIntent().getBooleanExtra("Created", false);
        saveNoteButton = findViewById(R.id.saveNoteButton);
        deleteNoteButton = findViewById(R.id.deleteNoteButton);
        noteEditText = findViewById(R.id.noteEditText);
        if (created)
        {
            saveNoteButton.setText("Update Note");
            deleteNoteButton.setVisibility(View.VISIBLE);
            deleteNoteButton.setEnabled(true);
        }
        else
        {
            saveNoteButton.setText("Save Note");
            deleteNoteButton.setVisibility(View.INVISIBLE);
            deleteNoteButton.setEnabled(false);
        }
        db = new DatabaseHelper(this);
        if(getIntent().getStringExtra("Note")!=null) {
            currentNote = new Note(getIntent().getStringExtra("Note"));
            noteEditText.setText(currentNote.getNote());
        }
        saveNoteButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                noteMessage = noteEditText.getText().toString();
                if (noteMessage.equals(""))
                {
                    Toast.makeText(NoteActivity.this, "An error occurred", Toast.LENGTH_SHORT).show();
                }
                else if (created == false)
                {

                    Note note = new Note(noteMessage);
                    db.insertNote(note);
                    note.setCreated(true);
                    created = true;
                    Intent showIntent = new Intent(NoteActivity.this, NoteListActivity.class);
                    startActivity(showIntent);
                    finish();
                }
                else
                {
                    Integer updated = db.updateNote(currentNote, new Note(noteEditText.getText().toString()));
                    startActivity(new Intent(NoteActivity.this, NoteListActivity.class));
                    finish();
                }
            }
        });
        deleteNoteButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Integer deleted = db.deleteNote(currentNote);
                startActivity(new Intent(NoteActivity.this, NoteListActivity.class));
                finish();
            }
        });
    }
}