package com.example.notesapp;

import android.content.Context;
import android.support.annotation.NonNull;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import java.util.List;

public class NoteAdapter extends RecyclerView.Adapter<NoteAdapter.NoteViewHolder> {
    private List<Note> noteList;
    private Context context;
    private OnRowClickListener listener;

    public NoteAdapter(List<Note> noteList, Context context, OnRowClickListener clickListener) {
        this.noteList = noteList;
        this.context = context;
        this.listener = clickListener;
    }

    @NonNull
    @Override
    public NoteViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View itemView = LayoutInflater.from(context).inflate(R.layout.note_recycler_view, parent, false);
        return new NoteViewHolder(itemView, listener);
    }

    public interface OnRowClickListener {
        void onItemClick(int position);
    }

    public class NoteViewHolder extends RecyclerView.ViewHolder implements View.OnClickListener {
        public TextView noteTextView;
        public OnRowClickListener onRowClickListener;

        public NoteViewHolder(@NonNull View itemView, OnRowClickListener onRowClickListener) {
            super(itemView);
            noteTextView = itemView.findViewById(R.id.noteTextView);
            this.onRowClickListener = onRowClickListener;
            itemView.setOnClickListener(this);
        }
        @Override
        public void onClick(View view) {
            onRowClickListener.onItemClick(getAdapterPosition());
        }
    }

    @Override
    public void onBindViewHolder(NoteViewHolder holder, int position) {
        holder.noteTextView.setText(noteList.get(position).getNote());
    }

    @Override
    public int getItemCount() {
        return noteList.size();
    }
}
